import { Telegraf, Context, Markup } from 'telegraf';
import { message } from 'telegraf/filters';
import { 
  TELEGRAM_BOT_TOKEN, 
  TELEGRAM_GROUP_ID, 
  TELEGRAM_OWNER_ID,
  APP_BASE_URL 
} from './config';
import { db } from './db';
import { stripeUtils } from './stripe';
import { logger, isOwner, formatCurrency, formatDate, escapeMarkdown } from './utils';
import { jobQueue } from './jobs';
import { processMedia } from './media';

// Extend context with custom properties
interface BotContext extends Context {
  user?: {
    id: string;
    telegramId: number;
    username?: string;
    subscription?: any;
  };
}

// Initialize bot
export const bot = new Telegraf<BotContext>(TELEGRAM_BOT_TOKEN);

// Middleware to load user data
bot.use(async (ctx, next) => {
  if (ctx.from) {
    const user = await db.user.findByTelegramId(ctx.from.id);
    if (user) {
      ctx.user = {
        id: user.id,
        telegramId: Number(user.telegramId),
        username: user.username || undefined,
        subscription: user.subscriptions[0] || null,
      };
    }
  }
  await next();
});

// Error handler
bot.catch((err, ctx) => {
  logger.error({ error: err, userId: ctx.from?.id }, 'Bot error occurred');
  ctx.reply('❌ An error occurred. Please try again later.');
});

// Start command
bot.command('start', async (ctx) => {
  const user = ctx.from;
  if (!user) return;

  try {
    // Check if user exists (to determine if this is first interaction)
    const existingUser = await db.user.findByTelegramId(user.id);
    const isNewUser = !existingUser;

    // Upsert user
    await db.user.upsert({
      telegramId: user.id,
      username: user.username,
      firstName: user.first_name,
      lastName: user.last_name,
    });

    // Check if user has active subscription
    const dbUser = await db.user.findByTelegramId(user.id);
    if (dbUser?.subscriptions[0]) {
      const sub = dbUser.subscriptions[0];
      
      // Translate plan name to English
      const englishName = sub.plan.name === 'Piano Mensile' ? 'Monthly Plan' : 
                         sub.plan.name === 'Piano 3 Mesi' ? '3-Month Plan' : sub.plan.name;
      
      await ctx.reply(
        `✅ Welcome back! You have an active ${englishName} subscription.\n\n` +
        `📅 Next renewal: ${formatDate(sub.currentPeriodEnd)}\n\n` +
        `Use /account to manage your subscription.`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '👥 Join Group', url: `https://t.me/${TELEGRAM_GROUP_ID}` }],
              [{ text: '⚙️ Manage Account', callback_data: 'account' }],
            ],
          },
        }
      );
      return;
    }

    // Show welcome message for new users
    if (isNewUser) {
      await ctx.reply(
        `🍕 *Welcome to DurianOnPizza Premium!*\n\n` +
        `Ready to join the most exclusive content club on Telegram? 🔥\n\n` +
        `We've got the spiciest, most premium content you won't find ANYWHERE else! 🌶️✨\n\n` +
        `👉👉👉 Hit /start to see our plans and join the party! 🎉\n\n` +
        `Trust me, you don't want to miss this. 😏`,
        { parse_mode: 'Markdown' }
      );
      
      // Wait a moment before showing plans
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    // Show available plans
    await showPlans(ctx);
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error in start command');
    await ctx.reply('❌ An error occurred. Please try again later.');
  }
});

// Plans command
bot.command('plans', showPlans);

async function showPlans(ctx: BotContext) {
  try {
    const plans = await db.plan.findAll();
    
    if (plans.length === 0) {
      await ctx.reply('❌ No subscription plans available at the moment.');
      return;
    }

    let message = '🎯 *Choose Your Plan*\n\n';
    message += '🔥 Get exclusive access to premium content and community!\n\n';
    message += '🚫 *Protected Content*: No screenshots, no downloads, no sharing\n\n';

    const keyboard = [];
    
    for (const plan of plans) {
      const price = formatCurrency(plan.priceCents);
      let description = 'monthly';
      
      if (plan.name.includes('3 Mesi')) {
        description = 'every 3 months';
      }
      
      // Translate plan names to English
      const englishName = plan.name === 'Piano Mensile' ? 'Monthly Plan' : 
                         plan.name === 'Piano 3 Mesi' ? '3-Month Plan' : plan.name;
      
      message += `💎 *${englishName}*\n`;
      message += `💰 ${price} ${description}\n`;
      message += `🔄 Auto-renewal\n\n`;
      
      keyboard.push([{
        text: `🚀 Subscribe ${englishName} (${price})`,
        callback_data: `subscribe_${plan.id}`,
      }]);
    }

    // Add FAQ button at the bottom
    keyboard.push([{ text: '❓ FAQ', callback_data: 'faq_menu' }]);

    // Send video with the message as caption
    try {
      await ctx.replyWithVideo('BAACAgQAAxkBAAMYaLAw5SEtDImBdQSyrchAcKYTvncAAtkbAAIVn4BR8n9DY8gHaIc2BA', {
        caption: message,
        parse_mode: 'Markdown',
        protect_content: true,
        reply_markup: { inline_keyboard: keyboard },
      });
    } catch (videoError) {
      logger.warn({ error: videoError }, 'Video not available, sending text only');
      // Fallback: send text only if video fails
      await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: keyboard },
      });
    }
  } catch (error) {
    logger.error({ error }, 'Error showing plans');
    await ctx.reply('❌ Error loading plans. Please try again later.');
  }
}

// Account command
bot.command('account', async (ctx) => {
  const user = ctx.from;
  if (!user) return;

  try {
    const dbUser = await db.user.findByTelegramId(user.id);
    if (!dbUser?.subscriptions[0]) {
      await ctx.reply(
        '❌ You don\'t have an active subscription.\n\n' +
        'Use /start to see available plans.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '🛒 View Plans', callback_data: 'plans' }],
            ],
          },
        }
      );
      return;
    }

    const sub = dbUser.subscriptions[0];
    const nextRenewal = formatDate(sub.currentPeriodEnd);
    const status = sub.status === 'active' ? '✅ Active' : '⚠️ ' + sub.status;
    
    let intervalText = 'monthly';
    if (sub.plan.name.includes('3 Mesi')) {
      intervalText = 'every 3 months';
    }

    // Translate plan name to English
    const englishName = sub.plan.name === 'Piano Mensile' ? 'Monthly Plan' : 
                       sub.plan.name === 'Piano 3 Mesi' ? '3-Month Plan' : sub.plan.name;

    await ctx.reply(
      `📊 **Your Account**\n\n` +
      `📋 Plan: ${englishName}\n` +
      `💰 Price: ${formatCurrency(sub.plan.priceCents)} ${intervalText}\n` +
      `📈 Status: ${status}\n` +
      `📅 Next renewal: ${nextRenewal}\n` +
      `🔄 Auto-renewal ${sub.cancelAtPeriodEnd ? '❌ DISABLED' : '✅ ENABLED'}\n` +
      `${sub.cancelAtPeriodEnd ? '⚠️ Subscription will expire at the end of the period' : ''}`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⚙️ Manage Subscription', callback_data: 'billing_portal' }],
            [{ text: '👥 Join Group', url: `https://t.me/${TELEGRAM_GROUP_ID}` }],
          ],
        },
      }
    );
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error in account command');
    await ctx.reply('❌ Error loading account info. Please try again later.');
  }
});

// Owner-only commands
bot.command('upload', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ This command is only available to administrators.');
    return;
  }

  await ctx.reply(
    '📤 **Upload Content**\n\n' +
    'Send me a photo or video to publish in the group.\n' +
    'You can include a caption with your content.\n\n' +
    '🔒 Content will be automatically protected (no screenshot, no download).',
    { parse_mode: 'Markdown' }
  );
});

bot.command('broadcast', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ This command is only available to administrators.');
    return;
  }

  const text = ctx.message.text.replace('/broadcast', '').trim();
  if (!text) {
    await ctx.reply('❌ Please provide a message to send.\n\nExample: `/broadcast Hello everyone!`');
    return;
  }

  try {
    await bot.telegram.sendMessage(TELEGRAM_GROUP_ID, text, {
      protect_content: true,
      parse_mode: 'Markdown',
    });
    
    await ctx.reply('✅ Message sent successfully to the group!');
    logger.info({ text }, 'Broadcasted message to group');
  } catch (error) {
    logger.error({ error, text }, 'Failed to broadcast message');
    await ctx.reply('❌ Error sending message.');
  }
});

bot.command('stats', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ This command is only available to administrators.');
    return;
  }

  try {
    const stats = await db.analytics.getStats();
    const activeSubscriptions = await db.subscription.getActiveSubscriptions();
    
    // Calculate MRR
    let monthlyRevenue = 0;
    for (const sub of activeSubscriptions) {
      if (sub.plan.interval === 'month') {
        monthlyRevenue += sub.plan.priceCents;
      } else if (sub.plan.interval === 'year') {
        monthlyRevenue += Math.round(sub.plan.priceCents / 12);
      }
    }

    await ctx.reply(
      `📊 **Bot Statistics**\n\n` +
      `👥 Total Users: ${stats.totalUsers}\n` +
      `✅ Active Subscriptions: ${stats.activeSubscriptions}\n` +
      `💰 Monthly Recurring Revenue: ${formatCurrency(monthlyRevenue)}\n` +
      `📈 New Users (30d): ${stats.recentSignups}\n`,
      { parse_mode: 'Markdown' }
    );
  } catch (error) {
    logger.error({ error }, 'Error getting stats');
    await ctx.reply('❌ Error loading statistics.');
  }
});

// Help command
bot.command('help', async (ctx) => {
  const isAdmin = isOwner(ctx.from?.id || 0);
  
  let message = '🤖 **Bot Commands**\n\n';
  message += '👤 **User Commands:**\n';
  message += '• `/start` - View subscription plans\n';
  message += '• `/plans` - Show available plans\n';
  message += '• `/account` - Manage your subscription\n';
  message += '• `/help` - Show this help message\n\n';
  message += '🔒 **Protected Content:**\n';
  message += '• No screenshots possible\n';
  message += '• No video downloads\n';
  message += '• No external sharing\n';
  
  if (isAdmin) {
    message += '\n🔧 **Admin Commands:**\n';
    message += '• `/upload` - Upload content to group\n';
    message += '• `/broadcast <message>` - Send message to group\n';
    message += '• `/stats` - View bot statistics\n';
  }

  await ctx.reply(message, { parse_mode: 'Markdown' });
});

// Handle callback queries
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery.data;
  if (!data) return;

  try {
    await ctx.answerCbQuery();

    if (data.startsWith('subscribe_')) {
      const planId = data.replace('subscribe_', '');
      await handleSubscribe(ctx, planId);
    } else if (data === 'account') {
      await ctx.deleteMessage();
      await bot.handleUpdate({
        update_id: 0,
        message: {
          message_id: 0,
          date: Math.floor(Date.now() / 1000),
          chat: ctx.chat!,
          from: ctx.from!,
          text: '/account',
        },
      } as any);
    } else if (data === 'plans') {
      await ctx.deleteMessage();
      await showPlans(ctx);
    } else if (data === 'billing_portal') {
      await handleBillingPortal(ctx);
    } else if (data.startsWith('faq_')) {
      await handleFAQ(ctx, data);
    }
  } catch (error) {
    logger.error({ error, data }, 'Error handling callback query');
    await ctx.answerCbQuery('❌ An error occurred. Please try again.');
  }
});

async function handleSubscribe(ctx: BotContext, planId: string) {
  const user = ctx.from;
  if (!user) return;

  try {
    const plan = await db.plan.findById?.(planId);
    if (!plan) {
      await ctx.reply('❌ Plan not found.');
      return;
    }

    // Create Stripe checkout session
    const session = await stripeUtils.createCheckoutSession({
      priceId: plan.stripePriceId,
      telegramId: user.id,
      username: user.username,
      successUrl: `${APP_BASE_URL}/success`,
      cancelUrl: `${APP_BASE_URL}/cancel`,
    });

    let intervalText = 'monthly';
    if (plan.name.includes('3 Mesi')) {
      intervalText = 'every 3 months';
    }

    // Translate plan name to English
    const englishName = plan.name === 'Piano Mensile' ? 'Monthly Plan' : 
                       plan.name === 'Piano 3 Mesi' ? '3-Month Plan' : plan.name;

    await ctx.reply(
      `🛒 **Checkout Link Created**\n\n` +
      `Plan: ${englishName}\n` +
      `Price: ${formatCurrency(plan.priceCents)} ${intervalText}\n` +
      `🔄 Auto-renewal\n` +
      `🔒 Protected content (no screenshot/download)\n\n` +
      `Click the button below to complete your subscription:`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💳 Complete Payment', url: session.url! }],
            [{ text: '🔙 Back to Plans', callback_data: 'plans' }],
          ],
        },
      }
    );

    logger.info(
      { sessionId: session.id, planId, userId: user.id },
      'Created checkout session for user'
    );
  } catch (error) {
    logger.error({ error, planId, userId: user.id }, 'Error creating checkout session');
    await ctx.reply('❌ Error creating checkout session. Please try again later.');
  }
}

async function handleBillingPortal(ctx: BotContext) {
  const user = ctx.from;
  if (!user) return;

  try {
    const dbUser = await db.user.findByTelegramId(user.id);
    if (!dbUser?.subscriptions[0]) {
      await ctx.reply('❌ No active subscription found.');
      return;
    }

    const session = await stripeUtils.createBillingPortalSession(
      dbUser.subscriptions[0].stripeCustomerId,
      APP_BASE_URL
    );

    await ctx.reply(
      '⚙️ **Manage Your Subscription**\n\n' +
      'Click the button below to access the billing portal where you can:\n' +
      '• Update payment method\n' +
      '• Download invoices\n' +
      '• Cancel subscription\n' +
      '• Update billing information\n\n' +
      '⚠️ **WARNING**: If you cancel your subscription, you will be automatically removed from the group at the end of the current billing period.',
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⚙️ Open Billing Portal', url: session.url }],
          ],
        },
      }
    );
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error creating billing portal session');
    await ctx.reply('❌ Error accessing billing portal. Please try again later.');
  }
}

async function handleFAQ(ctx: BotContext, category: string) {
  let message = '';
  let backButton = [{ text: '🔙 Back to FAQ Menu', callback_data: 'faq_menu' }];

  switch (category) {
    case 'faq_payment':
      message = `💳 *Payment & Billing FAQ*\n\n` +
        `💰 *How do I pay for my subscription?*\n` +
        `We use Stripe - the most secure payment processor worldwide! 🔐 Your payment info is safe with us.\n\n` +
        
        `📅 *When will I be charged?*\n` +
        `You'll be charged every 1st of the month 📆 for monthly plans, or every 3 months for quarterly plans.\n\n` +
        
        `❌ *Can I cancel anytime?*\n` +
        `Yes, you can cancel anytime! ⚠️ But remember: once you cancel, you'll be kicked from the group immediately.\n\n` +
        
        `🏦 *What payment methods do you accept?*\n` +
        `We accept all major cards via Stripe 💳 Visa, Mastercard, American Express - you name it!\n\n` +
        
        `💸 *Will I get a refund if I cancel?*\n` +
        `Sorry, no refunds! 🚫 All sales are final. Make sure you're ready to commit! 💪`;
      break;

    case 'faq_content':
      message = `🔒 *Content & Features FAQ*\n\n` +
        `🎯 *What type of content will I get?*\n` +
        `Super exclusive and premium content by DurianOnPizza! 🍕✨ Content you won't find anywhere else!\n\n` +
        
        `📱 *Can I download videos?*\n` +
        `NO! 🚨 All videos are protected. Any attempts to download or record will result in legal action! ⚖️ We take this seriously.\n\n` +
        
        `📈 *How often is new content posted?*\n` +
        `Multiple premium contents weekly! 🔥 Always fresh, always exclusive! 📅`;
      break;

    case 'faq_general':
      message = `📱 *General Questions FAQ*\n\n` +
        `🤖 *How does the bot work?*\n` +
        `Simple: Pay = Access ✅ Don't pay = Get kicked ❌ It's automatic and fair! 🎯\n\n` +
        
        `💬 *Who can I contact for support?*\n` +
        `Need help? Contact @marcogirobondo 👨‍💻 He'll sort you out!`;
      break;

    case 'faq_menu':
      // Return to main FAQ menu
      const faqMessage = `❓ *Frequently Asked Questions*\n\n` +
        `Choose a category to get answers:`;

      const keyboard = [
        [
          { text: '💳 Payment & Billing', callback_data: 'faq_payment' },
          { text: '🔒 Content & Features', callback_data: 'faq_content' }
        ],
        [
          { text: '📱 General Questions', callback_data: 'faq_general' }
        ],
        [
          { text: '🔙 Back to Main Menu', callback_data: 'plans' }
        ]
      ];

      await ctx.reply(faqMessage, {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: keyboard }
      });
      return;
  }

  await ctx.reply(message, {
    parse_mode: 'Markdown',
    reply_markup: { inline_keyboard: [backButton] }
  });
}

// Handle media uploads from owner
bot.on(message('photo'), async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) return;

  try {
    const photo = ctx.message.photo[ctx.message.photo.length - 1]!;
    const caption = ctx.message.caption;

    // Process and post media
    const processedMedia = await processMedia({
      type: 'photo',
      fileId: photo.file_id,
      caption,
    });

    // Send to group with content protection
    const sentMessage = await bot.telegram.sendPhoto(TELEGRAM_GROUP_ID, processedMedia.fileId, {
      caption: processedMedia.caption,
      protect_content: true,
      parse_mode: 'Markdown',
    });

    // Save to database
    await db.mediaPost.create({
      type: 'PHOTO',
      fileId: processedMedia.fileId,
      caption: processedMedia.caption,
      postedByUserId: ctx.user?.id,
    });

    await ctx.reply('✅ Photo posted to group successfully! 🔒 Protected content.');
    logger.info({ fileId: photo.file_id, messageId: sentMessage.message_id }, 'Posted photo to group');
  } catch (error) {
    logger.error({ error }, 'Error posting photo to group');
    await ctx.reply('❌ Error posting photo to group.');
  }
});

bot.on(message('video'), async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) return;

  try {
    const video = ctx.message.video;
    const caption = ctx.message.caption;

    // Process and post media
    const processedMedia = await processMedia({
      type: 'video',
      fileId: video.file_id,
      caption,
    });

    // Send to group with content protection
    const sentMessage = await bot.telegram.sendVideo(TELEGRAM_GROUP_ID, processedMedia.fileId, {
      caption: processedMedia.caption,
      protect_content: true,
      parse_mode: 'Markdown',
    });

    // Save to database
    await db.mediaPost.create({
      type: 'VIDEO',
      fileId: processedMedia.fileId,
      caption: processedMedia.caption,
      postedByUserId: ctx.user?.id,
    });

    await ctx.reply('✅ Video posted to group successfully! 🔒 Protected content.');
    logger.info({ fileId: video.file_id, messageId: sentMessage.message_id }, 'Posted video to group');
  } catch (error) {
    logger.error({ error }, 'Error posting video to group');
    await ctx.reply('❌ Error posting video to group.');
  }
});

// Telegram service for external use
export const telegramService = {
  async grantAccess(telegramId: number, expiresAt: Date) {
    try {
      // Create invite link
      const inviteLink = await bot.telegram.createChatInviteLink(TELEGRAM_GROUP_ID, {
        member_limit: 1,
        expire_date: Math.floor(expiresAt.getTime() / 1000),
      });

      // Save invite token
      const user = await db.user.findByTelegramId(telegramId);
      if (user) {
        await db.inviteToken.create({
          userId: user.id,
          chatInviteLink: inviteLink.invite_link,
          expiresAt,
        });

        // Send invite link to user
        await bot.telegram.sendMessage(telegramId, 
          `🎉 **Welcome to Premium!**\n\n` +
          `Your subscription is now active. Click the link below to join our exclusive group:\n\n` +
          `🔗 ${inviteLink.invite_link}\n\n` +
          `⚠️ This link is personal and expires on ${formatDate(expiresAt)}\n\n` +
          `🔒 **Protected content**: You will not be able to screenshot, download videos, or share content outside the group.`,
          { parse_mode: 'Markdown' }
        );
      }

      logger.info({ telegramId, expiresAt }, 'Granted access to user');
    } catch (error) {
      logger.error({ error, telegramId }, 'Failed to grant access');
      throw error;
    }
  },

  async revokeAccess(telegramId: number, reason: string) {
    try {
      // Try to kick user from group
      try {
        await bot.telegram.banChatMember(TELEGRAM_GROUP_ID, telegramId);
        await bot.telegram.unbanChatMember(TELEGRAM_GROUP_ID, telegramId);
      } catch (error) {
        // User might not be in group, continue
        logger.warn({ error, telegramId }, 'Could not kick user from group');
      }

      // Revoke all invite tokens
      const user = await db.user.findByTelegramId(telegramId);
      if (user) {
        await db.inviteToken.revokeUserTokens(user.id);
      }

      // Notify user
      await bot.telegram.sendMessage(telegramId,
        `❌ **Access Revoked**\n\n` +
        `Your access has been revoked: ${reason}\n\n` +
        `To regain access, renew your subscription using /start\n\n` +
        `💬 If you have questions, contact support.`,
        { parse_mode: 'Markdown' }
      );

      logger.info({ telegramId, reason }, 'Revoked access for user');
    } catch (error) {
      logger.error({ error, telegramId, reason }, 'Failed to revoke access');
      throw error;
    }
  },

  async scheduleRemoval(telegramId: number, removalTime: Date, reason: string) {
    try {
      // Schedule job for removal
      await jobQueue.add('removeUser', {
        telegramId,
        reason,
      }, {
        delay: removalTime.getTime() - Date.now(),
        removeOnComplete: true,
        removeOnFail: false,
      });

      logger.info({ telegramId, removalTime, reason }, 'Scheduled user removal');
    } catch (error) {
      logger.error({ error, telegramId, removalTime, reason }, 'Failed to schedule removal');
      throw error;
    }
  },

  async notifyPaymentFailed(telegramId: number, graceHours: number) {
    try {
      await bot.telegram.sendMessage(telegramId,
        `⚠️ **Pagamento Fallito**\n\n` +
        `Non siamo riusciti a elaborare il tuo ultimo pagamento. Hai ${graceHours} ore per aggiornare il metodo di pagamento prima che l'accesso venga revocato.\n\n` +
        `🔄 **Rinnovo automatico**: Il tuo abbonamento si rinnoverà automaticamente una volta risolto il problema di pagamento.\n\n` +
        `Usa /account per gestire il tuo abbonamento.`,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [{ text: '⚙️ Aggiorna Pagamento', callback_data: 'billing_portal' }],
            ],
          },
        }
      );

      logger.info({ telegramId, graceHours }, 'Notified user about payment failure');
    } catch (error) {
      logger.error({ error, telegramId }, 'Failed to notify about payment failure');
      throw error;
    }
  },
};

// Export bot instance
export default bot;