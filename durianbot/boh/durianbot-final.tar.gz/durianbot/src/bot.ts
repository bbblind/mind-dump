import { Telegraf, Context, Markup } from 'telegraf';
import { message } from 'telegraf/filters';
import { 
  TELEGRAM_BOT_TOKEN, 
  TELEGRAM_GROUP_ID, 
  TELEGRAM_OWNER_ID,
  APP_BASE_URL 
} from './config';
import { db } from './db';
import { stripeUtils } from './stripe';
import { logger, isOwner, formatCurrency, formatDate, escapeMarkdown } from './utils';
import { jobQueue } from './jobs';
import { processMedia } from './media';

// Extend context with custom properties
interface BotContext extends Context {
  user?: {
    id: string;
    telegramId: number;
    username?: string;
    subscription?: any;
  };
}

// Initialize bot
export const bot = new Telegraf<BotContext>(TELEGRAM_BOT_TOKEN);

// Middleware to load user data
bot.use(async (ctx, next) => {
  if (ctx.from) {
    const user = await db.user.findByTelegramId(ctx.from.id);
    if (user) {
      ctx.user = {
        id: user.id,
        telegramId: Number(user.telegramId),
        username: user.username || undefined,
        subscription: user.subscriptions[0] || null,
      };
    }
  }
  await next();
});

// Error handler
bot.catch((err, ctx) => {
  logger.error({ error: err, userId: ctx.from?.id }, 'Bot error occurred');
  ctx.reply('❌ An error occurred. Please try again later.');
});

// Start command
bot.command('start', async (ctx) => {
  const user = ctx.from;
  if (!user) return;

  try {
    // Upsert user
    await db.user.upsert({
      telegramId: user.id,
      username: user.username,
      firstName: user.first_name,
      lastName: user.last_name,
    });

    // Check if user has active subscription
    const dbUser = await db.user.findByTelegramId(user.id);
    if (dbUser?.subscriptions[0]) {
      const sub = dbUser.subscriptions[0];
      await ctx.reply(
        `✅ Bentornato! Hai un abbonamento ${sub.plan.name} attivo.\n\n` +
        `📅 Prossimo rinnovo: ${formatDate(sub.currentPeriodEnd)}\n\n` +
        `Usa /account per gestire il tuo abbonamento.`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '👥 Entra nel Gruppo', url: `https://t.me/${TELEGRAM_GROUP_ID}` }],
              [{ text: '⚙️ Gestisci Account', callback_data: 'account' }],
            ],
          },
        }
      );
      return;
    }

    // Show available plans
    await showPlans(ctx);
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error in start command');
    await ctx.reply('❌ An error occurred. Please try again later.');
  }
});

// Plans command
bot.command('plans', showPlans);

async function showPlans(ctx: BotContext) {
  try {
    const plans = await db.plan.findAll();
    
    if (plans.length === 0) {
      await ctx.reply('❌ Nessun piano di abbonamento disponibile al momento.');
      return;
    }

    let message = '🎯 **Scegli il Tuo Piano**\n\n';
    message += '🔥 Ottieni accesso esclusivo a contenuti premium e alla community!\n\n';
    message += '🚫 **Contenuti protetti**: No screenshot, no download, no condivisioni\n\n';

    const keyboard = [];
    
    for (const plan of plans) {
      const price = formatCurrency(plan.priceCents);
      let interval = 'mese';
      let description = 'mensile';
      
      if (plan.name.includes('3 Mesi')) {
        description = 'ogni 3 mesi';
        interval = '3 mesi';
      }
      
      message += `💎 **${plan.name}**\n`;
      message += `💰 ${price} ${description}\n`;
      message += `🔄 Rinnovo automatico\n\n`;
      
      keyboard.push([{
        text: `🚀 Abbonati ${plan.name} (${price})`,
        callback_data: `subscribe_${plan.id}`,
      }]);
    }

    await ctx.reply(message, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard },
    });
  } catch (error) {
    logger.error({ error }, 'Error showing plans');
    await ctx.reply('❌ Error loading plans. Please try again later.');
  }
}

// Account command
bot.command('account', async (ctx) => {
  const user = ctx.from;
  if (!user) return;

  try {
    const dbUser = await db.user.findByTelegramId(user.id);
    if (!dbUser?.subscriptions[0]) {
      await ctx.reply(
        '❌ Non hai un abbonamento attivo.\n\n' +
        'Usa /start per vedere i piani disponibili.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '🛒 Vedi Piani', callback_data: 'plans' }],
            ],
          },
        }
      );
      return;
    }

    const sub = dbUser.subscriptions[0];
    const nextRenewal = formatDate(sub.currentPeriodEnd);
    const status = sub.status === 'ACTIVE' ? '✅ Attivo' : '⚠️ ' + sub.status;
    
    let intervalText = 'mensile';
    if (sub.plan.name.includes('3 Mesi')) {
      intervalText = 'ogni 3 mesi';
    }

    await ctx.reply(
      `📊 **Il Tuo Account**\n\n` +
      `📋 Piano: ${sub.plan.name}\n` +
      `💰 Prezzo: ${formatCurrency(sub.plan.priceCents)} ${intervalText}\n` +
      `📈 Status: ${status}\n` +
      `📅 Prossimo rinnovo: ${nextRenewal}\n` +
      `🔄 Rinnovo automatico ${sub.cancelAtPeriodEnd ? '❌ DISATTIVATO' : '✅ ATTIVO'}\n` +
      `${sub.cancelAtPeriodEnd ? '⚠️ L\'abbonamento scadrà alla fine del periodo' : ''}`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⚙️ Gestisci Abbonamento', callback_data: 'billing_portal' }],
            [{ text: '👥 Entra nel Gruppo', url: `https://t.me/${TELEGRAM_GROUP_ID}` }],
          ],
        },
      }
    );
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error in account command');
    await ctx.reply('❌ Error loading account info. Please try again later.');
  }
});

// Owner-only commands
bot.command('upload', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ Questo comando è disponibile solo per gli amministratori.');
    return;
  }

  await ctx.reply(
    '📤 **Carica Contenuto**\n\n' +
    'Inviami una foto o un video da pubblicare nel gruppo.\n' +
    'Puoi includere una didascalia con il tuo contenuto.\n\n' +
    '🔒 Il contenuto sarà protetto automaticamente (no screenshot, no download).',
    { parse_mode: 'Markdown' }
  );
});

bot.command('broadcast', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ This command is only available to administrators.');
    return;
  }

  const text = ctx.message.text.replace('/broadcast', '').trim();
  if (!text) {
    await ctx.reply('❌ Fornisci un messaggio da inviare.\n\nEsempio: `/broadcast Ciao a tutti!`');
    return;
  }

  try {
    await bot.telegram.sendMessage(TELEGRAM_GROUP_ID, text, {
      protect_content: true,
      parse_mode: 'Markdown',
    });
    
    await ctx.reply('✅ Messaggio inviato con successo al gruppo!');
    logger.info({ text }, 'Broadcasted message to group');
  } catch (error) {
    logger.error({ error, text }, 'Failed to broadcast message');
    await ctx.reply('❌ Errore nell\'invio del messaggio.');
  }
});

bot.command('stats', async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) {
    await ctx.reply('❌ This command is only available to administrators.');
    return;
  }

  try {
    const stats = await db.analytics.getStats();
    const activeSubscriptions = await db.subscription.getActiveSubscriptions();
    
    // Calculate MRR
    let monthlyRevenue = 0;
    for (const sub of activeSubscriptions) {
      if (sub.plan.interval === 'month') {
        monthlyRevenue += sub.plan.priceCents;
      } else if (sub.plan.interval === 'year') {
        monthlyRevenue += Math.round(sub.plan.priceCents / 12);
      }
    }

    await ctx.reply(
      `📊 **Statistiche Bot**\n\n` +
      `👥 Utenti Totali: ${stats.totalUsers}\n` +
      `✅ Abbonamenti Attivi: ${stats.activeSubscriptions}\n` +
      `💰 Ricavi Mensili Ricorrenti: ${formatCurrency(monthlyRevenue)}\n` +
      `📈 Nuovi Utenti (30g): ${stats.recentSignups}\n`,
      { parse_mode: 'Markdown' }
    );
  } catch (error) {
    logger.error({ error }, 'Error getting stats');
    await ctx.reply('❌ Error loading statistics.');
  }
});

// Help command
bot.command('help', async (ctx) => {
  const isAdmin = isOwner(ctx.from?.id || 0);
  
  let message = '🤖 **Comandi Bot**\n\n';
  message += '👤 **Comandi Utente:**\n';
  message += '• `/start` - Vedi piani di abbonamento\n';
  message += '• `/plans` - Mostra piani disponibili\n';
  message += '• `/account` - Gestisci il tuo abbonamento\n';
  message += '• `/help` - Mostra questo messaggio di aiuto\n\n';
  message += '🔒 **Contenuti Protetti:**\n';
  message += '• Nessuno screenshot possibile\n';
  message += '• Nessun download video\n';
  message += '• Nessuna condivisione esterna\n';
  
  if (isAdmin) {
    message += '\n🔧 **Comandi Admin:**\n';
    message += '• `/upload` - Carica contenuto nel gruppo\n';
    message += '• `/broadcast <messaggio>` - Invia messaggio al gruppo\n';
    message += '• `/stats` - Vedi statistiche bot\n';
  }

  await ctx.reply(message, { parse_mode: 'Markdown' });
});

// Handle callback queries
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery.data;
  if (!data) return;

  try {
    await ctx.answerCbQuery();

    if (data.startsWith('subscribe_')) {
      const planId = data.replace('subscribe_', '');
      await handleSubscribe(ctx, planId);
    } else if (data === 'account') {
      await ctx.deleteMessage();
      await bot.handleUpdate({
        update_id: 0,
        message: {
          message_id: 0,
          date: Math.floor(Date.now() / 1000),
          chat: ctx.chat!,
          from: ctx.from!,
          text: '/account',
        },
      } as any);
    } else if (data === 'plans') {
      await ctx.deleteMessage();
      await showPlans(ctx);
    } else if (data === 'billing_portal') {
      await handleBillingPortal(ctx);
    }
  } catch (error) {
    logger.error({ error, data }, 'Error handling callback query');
    await ctx.answerCbQuery('❌ An error occurred. Please try again.');
  }
});

async function handleSubscribe(ctx: BotContext, planId: string) {
  const user = ctx.from;
  if (!user) return;

  try {
    const plan = await db.plan.findById?.(planId);
    if (!plan) {
      await ctx.reply('❌ Plan not found.');
      return;
    }

    // Create Stripe checkout session
    const session = await stripeUtils.createCheckoutSession({
      priceId: plan.stripePriceId,
      telegramId: user.id,
      username: user.username,
      successUrl: `${APP_BASE_URL}/success`,
      cancelUrl: `${APP_BASE_URL}/cancel`,
    });

    let intervalText = 'mensile';
    if (plan.name.includes('3 Mesi')) {
      intervalText = 'ogni 3 mesi';
    }

    await ctx.reply(
      `🛒 **Link Checkout Creato**\n\n` +
      `Piano: ${plan.name}\n` +
      `Prezzo: ${formatCurrency(plan.priceCents)} ${intervalText}\n` +
      `🔄 Rinnovo automatico\n` +
      `🔒 Contenuti protetti (no screenshot/download)\n\n` +
      `Clicca il pulsante sotto per completare l'abbonamento:`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💳 Completa Pagamento', url: session.url! }],
            [{ text: '🔙 Torna ai Piani', callback_data: 'plans' }],
          ],
        },
      }
    );

    logger.info(
      { sessionId: session.id, planId, userId: user.id },
      'Created checkout session for user'
    );
  } catch (error) {
    logger.error({ error, planId, userId: user.id }, 'Error creating checkout session');
    await ctx.reply('❌ Error creating checkout session. Please try again later.');
  }
}

async function handleBillingPortal(ctx: BotContext) {
  const user = ctx.from;
  if (!user) return;

  try {
    const dbUser = await db.user.findByTelegramId(user.id);
    if (!dbUser?.subscriptions[0]) {
      await ctx.reply('❌ No active subscription found.');
      return;
    }

    const session = await stripeUtils.createBillingPortalSession(
      dbUser.subscriptions[0].stripeCustomerId,
      APP_BASE_URL
    );

    await ctx.reply(
      '⚙️ **Gestisci il Tuo Abbonamento**\n\n' +
      'Clicca il pulsante sotto per accedere al portale di fatturazione dove puoi:\n' +
      '• Aggiornare il metodo di pagamento\n' +
      '• Scaricare le fatture\n' +
      '• Disdire l\'abbonamento\n' +
      '• Aggiornare le informazioni di fatturazione\n\n' +
      '⚠️ **ATTENZIONE**: Se disdici l\'abbonamento, sarai rimosso automaticamente dal gruppo alla scadenza del periodo corrente.',
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⚙️ Apri Portale Fatturazione', url: session.url }],
          ],
        },
      }
    );
  } catch (error) {
    logger.error({ error, userId: user.id }, 'Error creating billing portal session');
    await ctx.reply('❌ Error accessing billing portal. Please try again later.');
  }
}

// Handle media uploads from owner
bot.on(message('photo'), async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) return;

  try {
    const photo = ctx.message.photo[ctx.message.photo.length - 1]!;
    const caption = ctx.message.caption;

    // Process and post media
    const processedMedia = await processMedia({
      type: 'photo',
      fileId: photo.file_id,
      caption,
    });

    // Send to group with content protection
    const sentMessage = await bot.telegram.sendPhoto(TELEGRAM_GROUP_ID, processedMedia.fileId, {
      caption: processedMedia.caption,
      protect_content: true,
      parse_mode: 'Markdown',
    });

    // Save to database
    await db.mediaPost.create({
      type: 'PHOTO',
      fileId: processedMedia.fileId,
      caption: processedMedia.caption,
      postedByUserId: ctx.user?.id,
    });

    await ctx.reply('✅ Foto pubblicata nel gruppo con successo! 🔒 Contenuto protetto.');
    logger.info({ fileId: photo.file_id, messageId: sentMessage.message_id }, 'Posted photo to group');
  } catch (error) {
    logger.error({ error }, 'Error posting photo to group');
    await ctx.reply('❌ Error posting photo to group.');
  }
});

bot.on(message('video'), async (ctx) => {
  if (!isOwner(ctx.from?.id || 0)) return;

  try {
    const video = ctx.message.video;
    const caption = ctx.message.caption;

    // Process and post media
    const processedMedia = await processMedia({
      type: 'video',
      fileId: video.file_id,
      caption,
    });

    // Send to group with content protection
    const sentMessage = await bot.telegram.sendVideo(TELEGRAM_GROUP_ID, processedMedia.fileId, {
      caption: processedMedia.caption,
      protect_content: true,
      parse_mode: 'Markdown',
    });

    // Save to database
    await db.mediaPost.create({
      type: 'VIDEO',
      fileId: processedMedia.fileId,
      caption: processedMedia.caption,
      postedByUserId: ctx.user?.id,
    });

    await ctx.reply('✅ Video pubblicato nel gruppo con successo! 🔒 Contenuto protetto.');
    logger.info({ fileId: video.file_id, messageId: sentMessage.message_id }, 'Posted video to group');
  } catch (error) {
    logger.error({ error }, 'Error posting video to group');
    await ctx.reply('❌ Error posting video to group.');
  }
});

// Telegram service for external use
export const telegramService = {
  async grantAccess(telegramId: number, expiresAt: Date) {
    try {
      // Create invite link
      const inviteLink = await bot.telegram.createChatInviteLink(TELEGRAM_GROUP_ID, {
        member_limit: 1,
        expire_date: Math.floor(expiresAt.getTime() / 1000),
      });

      // Save invite token
      const user = await db.user.findByTelegramId(telegramId);
      if (user) {
        await db.inviteToken.create({
          userId: user.id,
          chatInviteLink: inviteLink.invite_link,
          expiresAt,
        });

        // Send invite link to user
        await bot.telegram.sendMessage(telegramId, 
          `🎉 **Benvenuto nel Premium!**\n\n` +
          `Il tuo abbonamento è ora attivo. Clicca il link sotto per entrare nel nostro gruppo esclusivo:\n\n` +
          `🔗 ${inviteLink.invite_link}\n\n` +
          `⚠️ Questo link è personale e scade il ${formatDate(expiresAt)}\n\n` +
          `🔒 **Contenuti protetti**: Non potrai fare screenshot, scaricare video o condividere i contenuti al di fuori del gruppo.`,
          { parse_mode: 'Markdown' }
        );
      }

      logger.info({ telegramId, expiresAt }, 'Granted access to user');
    } catch (error) {
      logger.error({ error, telegramId }, 'Failed to grant access');
      throw error;
    }
  },

  async revokeAccess(telegramId: number, reason: string) {
    try {
      // Try to kick user from group
      try {
        await bot.telegram.banChatMember(TELEGRAM_GROUP_ID, telegramId);
        await bot.telegram.unbanChatMember(TELEGRAM_GROUP_ID, telegramId);
      } catch (error) {
        // User might not be in group, continue
        logger.warn({ error, telegramId }, 'Could not kick user from group');
      }

      // Revoke all invite tokens
      const user = await db.user.findByTelegramId(telegramId);
      if (user) {
        await db.inviteToken.revokeUserTokens(user.id);
      }

      // Notify user
      await bot.telegram.sendMessage(telegramId,
        `❌ **Accesso Revocato**\n\n` +
        `Il tuo accesso è stato revocato: ${reason}\n\n` +
        `Per riottenere l'accesso, rinnova il tuo abbonamento usando /start\n\n` +
        `💬 Se hai domande, contatta il supporto.`,
        { parse_mode: 'Markdown' }
      );

      logger.info({ telegramId, reason }, 'Revoked access for user');
    } catch (error) {
      logger.error({ error, telegramId, reason }, 'Failed to revoke access');
      throw error;
    }
  },

  async scheduleRemoval(telegramId: number, removalTime: Date, reason: string) {
    try {
      // Schedule job for removal
      await jobQueue.add('removeUser', {
        telegramId,
        reason,
      }, {
        delay: removalTime.getTime() - Date.now(),
        removeOnComplete: true,
        removeOnFail: false,
      });

      logger.info({ telegramId, removalTime, reason }, 'Scheduled user removal');
    } catch (error) {
      logger.error({ error, telegramId, removalTime, reason }, 'Failed to schedule removal');
      throw error;
    }
  },

  async notifyPaymentFailed(telegramId: number, graceHours: number) {
    try {
      await bot.telegram.sendMessage(telegramId,
        `⚠️ **Pagamento Fallito**\n\n` +
        `Non siamo riusciti a elaborare il tuo ultimo pagamento. Hai ${graceHours} ore per aggiornare il metodo di pagamento prima che l'accesso venga revocato.\n\n` +
        `🔄 **Rinnovo automatico**: Il tuo abbonamento si rinnoverà automaticamente una volta risolto il problema di pagamento.\n\n` +
        `Usa /account per gestire il tuo abbonamento.`,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [{ text: '⚙️ Aggiorna Pagamento', callback_data: 'billing_portal' }],
            ],
          },
        }
      );

      logger.info({ telegramId, graceHours }, 'Notified user about payment failure');
    } catch (error) {
      logger.error({ error, telegramId }, 'Failed to notify about payment failure');
      throw error;
    }
  },
};

// Export bot instance
export default bot;