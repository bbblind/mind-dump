# 🚀 DurianBot Deployment Guide

## Quick Deployment to Linode (139.162.130.60)

### Prerequisites
- ✅ Linode server: 139.162.130.60
- ✅ Domain: durianbot.lyyrics.com → 139.162.130.60
- ✅ Stripe keys configured
- ✅ Telegram bot token

---

## Step 1: Upload Code to Server

### Option A: Using SCP (From your Mac)

```bash
# Create a tarball of your project (excluding node_modules)
cd /Users/al/Websites
tar -czf durianbot.tar.gz \
  --exclude='node_modules' \
  --exclude='*.db' \
  --exclude='*.log' \
  --exclude='.git' \
  durianbot/

# Upload to Linode
scp durianbot.tar.gz root@139.162.130.60:/root/

# SSH into server
ssh root@139.162.130.60
```

### Option B: Using Git (Recommended)

```bash
# On your Mac, initialize git and push to GitHub
cd /Users/al/Websites/durianbot
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo-url>
git push -u origin main

# Then on Linode
ssh root@139.162.130.60
cd /opt
git clone <your-github-repo-url> durianbot
cd durianbot
```

---

## Step 2: Setup Server (Run on Linode)

```bash
# SSH into your Linode
ssh root@139.162.130.60

# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
rm get-docker.sh

# Install Docker Compose
apt install docker-compose -y

# Install Nginx
apt install nginx -y

# Install Certbot for SSL
apt install certbot python3-certbot-nginx -y
```

---

## Step 3: Extract and Setup Code

```bash
# If using SCP method
cd /root
tar -xzf durianbot.tar.gz
mv durianbot /opt/durianbot
cd /opt/durianbot

# If using Git method
cd /opt/durianbot
```

---

## Step 4: Configure Environment

```bash
# Copy production environment file
cp env.production .env

# The file already has all your keys:
# - Telegram bot token
# - Stripe API keys
# - Webhook secret
# - Domain: durianbot.lyyrics.com

# Verify the .env file
cat .env
```

---

## Step 5: Configure Nginx

```bash
# Create Nginx configuration
cat > /etc/nginx/sites-available/durianbot << 'EOF'
server {
    listen 80;
    server_name durianbot.lyyrics.com;

    # Allow large file uploads (for videos)
    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts for long-running requests
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

# Enable the site
ln -s /etc/nginx/sites-available/durianbot /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default  # Remove default site

# Test Nginx configuration
nginx -t

# Reload Nginx
systemctl reload nginx
```

---

## Step 6: Get SSL Certificate

```bash
# Get Let's Encrypt SSL certificate
certbot --nginx -d durianbot.lyyrics.com

# Follow prompts:
# - Enter email address
# - Agree to terms
# - Choose "2: Redirect" to force HTTPS

# Certificate auto-renews every 90 days
```

---

## Step 7: Start the Bot

```bash
cd /opt/durianbot

# Build and start all services (PostgreSQL, Redis, App)
docker-compose up -d

# Wait 10 seconds for database to initialize
sleep 10

# Run database migrations
docker-compose exec app npx prisma migrate deploy

# Seed Stripe products and create plans
docker-compose exec app npm run seed

# Check logs
docker-compose logs -f app
```

You should see:
```
✅ Stripe products and prices setup completed
✅ Bot started successfully
```

---

## Step 8: Test the Bot

### 1. Test Health Endpoint
```bash
curl https://durianbot.lyyrics.com/health
# Should return: {"status":"ok"}
```

### 2. Test on Telegram
- Open Telegram
- Find @DurianOnPizzaBot
- Send `/start`
- You should see the welcome message with video
- Click a plan button
- You'll be redirected to Stripe Checkout (LIVE mode!)

### 3. Test Stripe Webhook
- Go to Stripe Dashboard → Webhooks
- Click your webhook endpoint
- You should see "Last delivery: Success"

---

## Step 9: Verify Stripe Integration

```bash
# Check if plans were created
docker-compose exec app npx prisma studio

# Or check directly in database
docker-compose exec db psql -U durianbot -d durianbot -c "SELECT * FROM plans;"
```

You should see 2 plans:
- Piano Mensile ($15.99)
- Piano 3 Mesi ($35.99)

---

## 🎉 Done! Your Bot is Live!

### What Happens Now:

1. ✅ Users can subscribe via Stripe Checkout
2. ✅ Payments go to YOUR Stripe account
3. ✅ Bot auto-grants access to Telegram group
4. ✅ Auto-renewal every month/3 months
5. ✅ Auto-kicks users who cancel or fail payment
6. ✅ Content protection enabled (no screenshots/downloads)

---

## 💰 Withdraw Money from Stripe

1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Click "Balance" → "Payouts"
3. Add your bank account
4. Set payout schedule (daily/weekly/monthly)
5. Money automatically transfers to your bank!

---

## 🔧 Useful Commands

```bash
# View logs
docker-compose logs -f app

# Restart bot
docker-compose restart app

# Stop everything
docker-compose down

# Update code (if using git)
git pull
docker-compose up -d --build

# Check running containers
docker ps

# Access database
docker-compose exec db psql -U durianbot -d durianbot

# Check Nginx logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

---

## 🆘 Troubleshooting

### Bot not responding?
```bash
docker-compose logs app | tail -50
```

### Database connection error?
```bash
docker-compose restart db
docker-compose restart app
```

### Stripe webhook failing?
- Check webhook URL: `https://durianbot.lyyrics.com/webhook/stripe`
- Verify webhook secret in `.env`
- Check Stripe Dashboard → Webhooks → Recent deliveries

### SSL certificate issues?
```bash
certbot renew --dry-run
```

---

## 📊 Monitor Your Bot

### Server Resources
```bash
docker stats

# Check disk space
df -h

# Check memory
free -h
```

### Database Size
```bash
docker-compose exec db psql -U durianbot -d durianbot -c "SELECT pg_size_pretty(pg_database_size('durianbot'));"
```

---

## 🔐 Security Checklist

- ✅ Firewall configured (allow 22, 80, 443)
- ✅ SSH key authentication enabled
- ✅ Regular backups enabled
- ✅ SSL certificate auto-renewal
- ✅ .env file secured (never commit to git)
- ✅ Database password is strong

---

## 📞 Support

If you need help:
- Check logs: `docker-compose logs -f app`
- Restart services: `docker-compose restart`
- Contact: @marcogirobondo on Telegram

**Your bot is ready to make money! 🚀💰**

