#!/bin/bash

# DurianBot Server Setup Script
# Run this ON YOUR LINODE SERVER after uploading the code

set -e

echo "🚀 DurianBot Server Setup"
echo "=========================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo "❌ Please run as root: sudo bash server-setup.sh"
  exit 1
fi

echo "📦 Step 1: Updating system..."
apt update && apt upgrade -y

echo ""
echo "🐳 Step 2: Installing Docker..."
if ! command -v docker &> /dev/null; then
  curl -fsSL https://get.docker.com -o get-docker.sh
  sh get-docker.sh
  rm get-docker.sh
  echo "✅ Docker installed"
else
  echo "✅ Docker already installed"
fi

echo ""
echo "🐳 Step 3: Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
  apt install docker-compose -y
  echo "✅ Docker Compose installed"
else
  echo "✅ Docker Compose already installed"
fi

echo ""
echo "🌐 Step 4: Installing Nginx..."
if ! command -v nginx &> /dev/null; then
  apt install nginx -y
  echo "✅ Nginx installed"
else
  echo "✅ Nginx already installed"
fi

echo ""
echo "🔒 Step 5: Installing Certbot (SSL)..."
if ! command -v certbot &> /dev/null; then
  apt install certbot python3-certbot-nginx -y
  echo "✅ Certbot installed"
else
  echo "✅ Certbot already installed"
fi

echo ""
echo "🔧 Step 6: Configuring Nginx..."
cat > /etc/nginx/sites-available/durianbot << 'EOF'
server {
    listen 80;
    server_name durianbot.lyyrics.com;

    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/durianbot /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and reload Nginx
nginx -t
systemctl reload nginx

echo "✅ Nginx configured"

echo ""
echo "🔒 Step 7: Getting SSL certificate..."
echo "📧 You'll be asked for an email address"
echo "📝 Choose option 2 (Redirect HTTP to HTTPS)"
echo ""
read -p "Press Enter to continue..."

certbot --nginx -d durianbot.lyyrics.com

echo ""
echo "✅ SSL certificate installed!"

echo ""
echo "🚀 Step 8: Starting the bot..."
cd /opt/durianbot

# Verify .env exists
if [ ! -f .env ]; then
  echo "⚠️  Creating .env from env.production..."
  cp env.production .env
fi

# Start services
echo "Starting Docker services..."
docker-compose up -d

echo "Waiting for database to initialize..."
sleep 15

echo "Running database migrations..."
docker-compose exec -T app npx prisma migrate deploy

echo "Seeding Stripe products..."
docker-compose exec -T app npm run seed

echo ""
echo "✅ Checking bot status..."
docker-compose ps

echo ""
echo "📋 Viewing recent logs..."
docker-compose logs --tail=20 app

echo ""
echo "================================================"
echo "🎉 DEPLOYMENT COMPLETE!"
echo "================================================"
echo ""
echo "🌐 Your bot is now live at:"
echo "   https://durianbot.lyyrics.com"
echo ""
echo "📱 Test on Telegram:"
echo "   1. Open @DurianOnPizzaBot"
echo "   2. Send /start"
echo "   3. Try subscribing!"
echo ""
echo "💰 Check Stripe Dashboard:"
echo "   https://dashboard.stripe.com"
echo ""
echo "📊 View logs:"
echo "   docker-compose logs -f app"
echo ""
echo "🔄 Restart bot:"
echo "   docker-compose restart app"
echo ""
echo "================================================"

