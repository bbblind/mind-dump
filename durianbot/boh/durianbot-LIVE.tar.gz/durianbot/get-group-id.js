// Script temporaneo per ottenere l'ID del gruppo
const { Telegraf } = require('telegraf');

// Inserisci qui il token del tuo bot
const BOT_TOKEN = '7551790641:AAHR89x5lWDVpGBXACC4LZLJSTzSuxviI3A';

const bot = new Telegraf(BOT_TOKEN);

bot.on('message', (ctx) => {
  console.log('📍 Informazioni Chat:');
  console.log('ID:', ctx.chat.id);
  console.log('Tipo:', ctx.chat.type);
  console.log('Titolo:', ctx.chat.title || 'N/A');
  
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    console.log('✅ Questo è l\'ID del gruppo da usare:', ctx.chat.id);
  }
});

bot.launch();
console.log('🤖 Bot avviato! Invia un messaggio nel gruppo per vedere l\'ID');
console.log('Premi Ctrl+C per fermare');