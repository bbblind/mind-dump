import sharp from 'sharp';
import { bot } from './bot';
import { logger } from './utils';
import fs from 'fs/promises';
import path from 'path';

/**
 * Download a file from Telegram and return the buffer
 */
async function downloadTelegramFile(fileId: string): Promise<Buffer> {
  try {
    const fileLink = await bot.telegram.getFileLink(fileId);
    const response = await fetch(fileLink.href);
    
    if (!response.ok) {
      throw new Error(`Failed to download file: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (error) {
    logger.error({ error, fileId }, 'Failed to download Telegram file');
    throw error;
  }
}

/**
 * Add watermark to image (works for any size/ratio)
 */
async function addWatermark(imageBuffer: Buffer, text: string = '@DurianOnPizza'): Promise<Buffer> {
  const image = sharp(imageBuffer);
  const metadata = await image.metadata();
  
  const width = metadata.width || 1280;
  const height = metadata.height || 720;
  
  // Calculate font size based on image dimensions (responsive)
  const fontSize = Math.max(Math.floor(Math.min(width, height) * 0.025), 12); // 2.5% of smallest dimension, min 12px
  const padding = Math.floor(fontSize * 0.8);
  
  // Create SVG with text (bottom-right corner)
  const svgText = `
    <svg width="${width}" height="${height}">
      <text
        x="${width - padding}"
        y="${height - padding}"
        font-family="Arial, sans-serif"
        font-size="${fontSize}"
        font-weight="bold"
        fill="white"
        fill-opacity="0.9"
        text-anchor="end"
        stroke="black"
        stroke-width="${Math.max(1, fontSize / 15)}"
        stroke-opacity="0.6"
      >${text}</text>
    </svg>
  `;
  
  return image
    .composite([{
      input: Buffer.from(svgText),
      blend: 'over'
    }])
    .toBuffer();
}

/**
 * Create a blurred preview of an image with watermark
 * Medium blur as requested (some details visible but heavily obscured)
 * Watermark is added as a sharp overlay AFTER blurring for crisp text
 */
export async function createBlurredImage(fileId: string): Promise<Buffer> {
  try {
    const imageBuffer = await downloadTelegramFile(fileId);
    
    const image = sharp(imageBuffer);
    const metadata = await image.metadata();
    const width = metadata.width || 1280;
    const height = metadata.height || 720;
    
    // Apply medium blur + darken + reduce quality
    const blurred = await sharp(imageBuffer)
      .blur(25) // Medium blur (25 out of possible 1000)
      .modulate({
        brightness: 0.6, // Darken by 40%
        saturation: 0.8  // Reduce saturation slightly
      })
      .toBuffer();
    
    // Add crisp watermark AFTER blurring as an overlay
    const fontSize = Math.max(Math.floor(Math.min(width, height) * 0.03), 16); // Larger, 3% of smallest dimension
    const padding = Math.floor(fontSize * 0.8);
    
    const svgWatermark = `
      <svg width="${width}" height="${height}">
        <text
          x="${width - padding}"
          y="${height - padding}"
          font-family="Arial, sans-serif"
          font-size="${fontSize}"
          font-weight="bold"
          fill="white"
          fill-opacity="1.0"
          text-anchor="end"
          stroke="black"
          stroke-width="${Math.max(2, fontSize / 10)}"
          stroke-opacity="0.8"
        >@DurianOnPizza</text>
      </svg>
    `;
    
    const watermarked = await sharp(blurred)
      .composite([{
        input: Buffer.from(svgWatermark),
        blend: 'over'
      }])
      .jpeg({ quality: 75 }) // Higher quality for watermark visibility
      .toBuffer();
    
    logger.info({ originalSize: imageBuffer.length, watermarkedSize: watermarked.length }, 'Created blurred image with watermark');
    
    return watermarked;
  } catch (error) {
    logger.error({ error, fileId }, 'Failed to create blurred image');
    throw error;
  }
}

/**
 * Add watermark to original (unlocked) image
 */
export async function addWatermarkToImage(fileId: string): Promise<Buffer> {
  try {
    const imageBuffer = await downloadTelegramFile(fileId);
    const watermarked = await addWatermark(imageBuffer);
    
    logger.info('Added watermark to original image');
    return watermarked;
  } catch (error) {
    logger.error({ error, fileId }, 'Failed to add watermark to image');
    throw error;
  }
}

/**
 * Create a blurred thumbnail from video
 * Extract first frame and blur it
 */
export async function createVideoThumbnail(fileId: string): Promise<Buffer> {
  try {
    // Download video
    const videoBuffer = await downloadTelegramFile(fileId);
    
    // Save temporarily
    const tempPath = path.join('/tmp', `video-${Date.now()}.mp4`);
    await fs.writeFile(tempPath, videoBuffer);
    
    // For now, create a simple "locked" placeholder
    // In production, you'd use FFmpeg to extract first frame
    // For simplicity, we'll create a gray rectangle with lock emoji overlay
    const thumbnail = await sharp({
      create: {
        width: 1280,
        height: 720,
        channels: 3,
        background: { r: 40, g: 40, b: 40 }
      }
    })
    .blur(50)
    .jpeg({ quality: 50 })
    .toBuffer();
    
    // Cleanup
    try {
      await fs.unlink(tempPath);
    } catch (e) {
      // Ignore cleanup errors
    }
    
    logger.info('Created video thumbnail');
    
    return thumbnail;
  } catch (error) {
    logger.error({ error, fileId }, 'Failed to create video thumbnail');
    throw error;
  }
}

/**
 * Upload blurred image/thumbnail to Telegram and get file ID
 */
export async function uploadBlurredPreview(
  chatId: number,
  blurredBuffer: Buffer,
  type: 'photo' | 'video'
): Promise<string> {
  try {
    if (type === 'photo') {
      const message = await bot.telegram.sendPhoto(chatId, {
        source: blurredBuffer
      });
      
      const photo = message.photo?.[message.photo.length - 1];
      if (!photo) {
        throw new Error('No photo in uploaded message');
      }
      
      return photo.file_id;
    } else {
      // For video, we send the thumbnail as a photo
      const message = await bot.telegram.sendPhoto(chatId, {
        source: blurredBuffer
      });
      
      const photo = message.photo?.[message.photo.length - 1];
      if (!photo) {
        throw new Error('No thumbnail in uploaded message');
      }
      
      return photo.file_id;
    }
  } catch (error) {
    logger.error({ error, type }, 'Failed to upload blurred preview');
    throw error;
  }
}

