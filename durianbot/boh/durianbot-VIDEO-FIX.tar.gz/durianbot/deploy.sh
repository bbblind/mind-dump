#!/bin/bash

# DurianBot Quick Deployment Script
# This script packages and uploads the bot to your Linode server

set -e

echo "🚀 DurianBot Deployment Script"
echo "================================"
echo ""

# Configuration
SERVER="139.162.130.60"
SERVER_USER="root"
SERVER_PATH="/opt/durianbot"
PROJECT_DIR="/Users/al/Websites/durianbot"

echo "📦 Step 1: Creating deployment package..."
cd /Users/al/Websites

# Create tarball excluding unnecessary files
tar -czf durianbot-deploy.tar.gz \
  --exclude='durianbot/node_modules' \
  --exclude='durianbot/*.db' \
  --exclude='durianbot/*.db-journal' \
  --exclude='durianbot/.git' \
  --exclude='durianbot/*.log' \
  --exclude='durianbot/coverage' \
  --exclude='durianbot/.env' \
  --exclude='durianbot/deploy.sh' \
  durianbot/

echo "✅ Package created: durianbot-deploy.tar.gz"
echo ""

echo "📤 Step 2: Uploading to Linode server..."
scp durianbot-deploy.tar.gz ${SERVER_USER}@${SERVER}:/tmp/

echo "✅ Upload complete!"
echo ""

echo "🔧 Step 3: Setting up on server..."
ssh ${SERVER_USER}@${SERVER} << 'ENDSSH'
set -e

echo "Creating directory..."
mkdir -p /opt
cd /opt

echo "Stopping existing services (if any)..."
if [ -d "durianbot" ]; then
  cd durianbot
  docker-compose down 2>/dev/null || true
  cd /opt
fi

echo "Extracting new version..."
tar -xzf /tmp/durianbot-deploy.tar.gz -C /opt
rm /tmp/durianbot-deploy.tar.gz

cd /opt/durianbot

echo "Setting up environment..."
if [ ! -f .env ]; then
  cp env.production .env
  echo "⚠️  Created .env file - please verify configuration!"
fi

echo "✅ Server setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. SSH into server: ssh root@139.162.130.60"
echo "2. cd /opt/durianbot"
echo "3. Follow DEPLOYMENT_GUIDE.md to:"
echo "   - Install Docker"
echo "   - Setup Nginx + SSL"
echo "   - Start the bot"
echo ""
ENDSSH

echo ""
echo "✅ Deployment package uploaded successfully!"
echo ""
echo "📖 Next: SSH into your server and follow the guide:"
echo "   ssh root@139.162.130.60"
echo "   cd /opt/durianbot"
echo "   cat DEPLOYMENT_GUIDE.md"
echo ""
echo "🎉 Almost there!"


