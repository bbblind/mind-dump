# 🚀 Quick Start - Deploy in 10 Minutes

## Option 1: Automated Deployment (Easiest!)

### On Your Mac:

```bash
cd /Users/al/Websites/durianbot
./deploy.sh
```

This will:
- Package your bot
- Upload to Linode
- Prepare everything

### Then SSH into Linode:

```bash
ssh root@139.162.130.60
cd /opt/durianbot
bash server-setup.sh
```

This will:
- Install Docker
- Setup Nginx + SSL
- Start your bot
- **Done!** 🎉

---

## Option 2: Manual Step-by-Step

### Step 1: Package and Upload (On Your Mac)

```bash
cd /Users/al/Websites
tar -czf durianbot.tar.gz \
  --exclude='durianbot/node_modules' \
  --exclude='durianbot/*.db' \
  durianbot/

scp durianbot.tar.gz root@139.162.130.60:/root/
```

### Step 2: SSH into Server

```bash
ssh root@139.162.130.60
```

### Step 3: Extract Code

```bash
cd /root
tar -xzf durianbot.tar.gz
mv durianbot /opt/durianbot
cd /opt/durianbot
cp env.production .env
```

### Step 4: Install Docker

```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
apt install docker-compose nginx certbot python3-certbot-nginx -y
```

### Step 5: Configure Nginx

```bash
cat > /etc/nginx/sites-available/durianbot << 'EOF'
server {
    listen 80;
    server_name durianbot.lyyrics.com;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -s /etc/nginx/sites-available/durianbot /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

### Step 6: Get SSL Certificate

```bash
certbot --nginx -d durianbot.lyyrics.com
# Choose option 2 (Redirect to HTTPS)
```

### Step 7: Start the Bot

```bash
cd /opt/durianbot
docker-compose up -d
sleep 10
docker-compose exec app npx prisma migrate deploy
docker-compose exec app npm run seed
```

### Step 8: Test

```bash
# Check health
curl https://durianbot.lyyrics.com/health

# View logs
docker-compose logs -f app
```

**Done!** Open Telegram and send `/start` to @DurianOnPizzaBot 🎉

---

## 🆘 Troubleshooting

### Bot not starting?
```bash
docker-compose logs app
```

### Check if services are running:
```bash
docker-compose ps
```

### Restart everything:
```bash
docker-compose restart
```

---

## ✅ Verification Checklist

- [ ] DNS points to 139.162.130.60
- [ ] Nginx is running: `systemctl status nginx`
- [ ] SSL certificate installed: `https://durianbot.lyyrics.com`
- [ ] Docker containers running: `docker-compose ps`
- [ ] Health check works: `curl https://durianbot.lyyrics.com/health`
- [ ] Bot responds on Telegram: `/start`
- [ ] Stripe webhook connected (check Stripe Dashboard)

---

## 💰 Start Making Money!

1. Share your bot: `@DurianOnPizzaBot`
2. Users subscribe → Stripe processes payment
3. Bot grants access automatically
4. Money goes to your Stripe account
5. Withdraw to your bank! 🤑

**Your bot is LIVE!** 🚀



